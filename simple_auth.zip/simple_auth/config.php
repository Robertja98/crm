<?php
/**
 * Simple Auth Configuration for CRM
 * 
 * IMPORTANT: Keep this file secure and do not commit to version control
 * Update for your production environment
 */

return [
    // Storage configuration (CSV files)
    'storage' => [
        'data_dir' => __DIR__ . '/data',  // Where CSV files are stored
    ],
    
    // Security settings
    'security' => [
        // Password hashing (PASSWORD_ARGON2ID is recommended for 2026)
        'password_algo' => PASSWORD_ARGON2ID,
        'password_options' => [
            'memory_cost' => 65536,  // 64 MB
            'time_cost' => 4,
            'threads' => 3,
        ],
        
        // Session settings
        'session_name' => 'CRM_SESSION',
        'session_lifetime' => 86400, // 24 hours in seconds
        // PRODUCTION: Set to true when using HTTPS
        'session_cookie_secure' => true,  // Set to true for production/HTTPS
        'session_cookie_httponly' => true,  // Prevent JavaScript access to cookies
        'session_cookie_samesite' => 'Lax',  // Changed from Strict to Lax for localhost compatibility
        
        // CSRF protection
        'csrf_token_name' => 'csrf_token',
        'csrf_token_length' => 32,
        
        // DEVELOPMENT ONLY: Bypass CSRF on localhost if cookies aren't working
        // ⚠️ SET TO FALSE IN PRODUCTION!
        'dev_bypass_csrf' => false,  // Set to false in production for security
        
        // Rate limiting
        'max_login_attempts' => 5,
        'lockout_duration' => 900, // 15 minutes in seconds
        'rate_limit_window' => 900, // 15 minutes
    ],
    
    // Application settings
    'app' => [
        'name' => 'CRM System',
        'base_url' => 'http://localhost/CRM',
        'require_email_verification' => false,
        'enable_2fa' => false,
        'admin_email' => 'admin@example.com',
    ],
    
    // Validation rules
    'validation' => [
        'username_min_length' => 3,
        'username_max_length' => 50,
        'password_min_length' => 8,
        'password_require_uppercase' => true,
        'password_require_lowercase' => true,
        'password_require_number' => true,
        'password_require_special' => true,
    ],
    
    // Logging
    'logging' => [
        'enabled' => true,
        'log_failed_logins' => true,
        'log_successful_logins' => true,
        'log_registrations' => true,
        'log_password_changes' => true,
    ],
];
